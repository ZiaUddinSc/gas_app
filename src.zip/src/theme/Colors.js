export default {
  primaryBGColor: '#145065',
  textPrimaryColor: '#145065',
  textColorSecondary:'#343a40',
  white: '#ffffff',
  black: '#000',
  textColor: 'rgb(100 116 139)',
  fontColor:'#475569',
  errorTextColor : 'red',
};
