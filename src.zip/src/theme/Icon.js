export default {
  icGoogle: require('../assets/icon/google.png'),
};
